
 <form enctype="multipart/form-data" action=" " method="post" id="block">

<input name="file[]" type="file" id="file"/>

 <input type="submit" value="Upload File" name="submit" id="upload" class="upload"/>

</form>

<button onclick="myFunction1()">Try it</button>

        <!-- END OF INNER FORM -->
<script>
var x=0;
function myFunction1() {

x++;

var div = document.createElement('div');
div.setAttribute('class', 'myclass'); // and make sure myclass has some styles in css
div.id = 'block'+x;

var input=document.createElement('input');
input.type='file';
input.id = 'file';
input.name='file[]';


var btn = document.createElement("BUTTON");
btn.setAttribute('class', 'myclass');
btn.id= 'block'+x;
btn.innerHTML = "Delete";
btn.setAttribute("onclick", "myFunction2(this.id)");

document.getElementById('block').appendChild(div);
document.getElementById(div.id).appendChild(input);
document.getElementById(div.id).appendChild(btn);
}

function  myFunction2(id){

var parent = document.getElementById("block");

var child1 = document.getElementById(id);

parent.removeChild(child1);

}
</script>
