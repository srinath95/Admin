
        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">PROPERTY CAMPAIGN</h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->

            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Property Campaign
                        </div>
                        <div class="panel-body">
                            <div class="row">
                                <div class="col-lg-12">

 <form enctype="multipart/form-data" action="<?php echo site_url('AdminController/file_upload');?>" method="post" id="block">

<input name="files[]" type="file" id="file" class="col-lg-4 btn btn-outline btn-default" style="margin-left:15px;"/>

 <input type="submit" value="Upload File" name="submit" id="upload" class="upload col-lg-2 pull-right btn btn-outline btn-default"/>

</form>
<div class="col-lg-12" style="align:center !important;">
&nbsp;
</div>
<div class="col-lg-12" style="align:center !important;">

<button onclick="myFunction1()"  class="col-lg-2 btn btn-primary text-center center-block">+Add</button>
</div></div></div></div></div></div></div>
        <!-- END OF INNER FORM -->
<script>
var x=0;
function myFunction1() {

x++;

var div = document.createElement('div');
div.setAttribute('class', 'col-lg-12 '); // and make sure myclass has some styles in css
div.id = 'block'+x;


var input=document.createElement('input');
input.type='file';
input.id = 'file';
input.name='files[]';
input.setAttribute('class', 'col-lg-4 btn btn-outline btn-default');

var btn = document.createElement("BUTTON");
btn.setAttribute('class', 'col-lg-2 btn btn-outline btn-default');
btn.id= 'block'+x;
btn.innerHTML = "Delete";
btn.setAttribute("onclick", "myFunction2(this.id)");

document.getElementById('block').appendChild(div);
document.getElementById(div.id).appendChild(input);
document.getElementById(div.id).appendChild(btn);
}

function  myFunction2(id){

var parent = document.getElementById("block");
var child1 = document.getElementById(id);
parent.removeChild(child1);

}
</script>
