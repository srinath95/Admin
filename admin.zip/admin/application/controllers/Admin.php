<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends CI_Controller {

	public function index(){

	}


	public function campaignpage(){

		$this->load->helper('form');
		$this->load->view('propertycampaign');

	}

	public function gallery(){

		$this->load->view('index');
		$this->load->view('gallery');
        $this->load->view('footer');


	}
}
