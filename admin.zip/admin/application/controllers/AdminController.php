<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class AdminController extends CI_Controller {

	public function Create_campaign(){

		echo "javedaldmlo;mopwempew";

		$config['upload_path'] = './assests/uploads/';
	    $config['allowed_types'] = 'gif|jpg|png|pdf';
	    $config['max_size'] = '3000000';
	    $config['max_width']  = '1000000';
	    $config['max_height']  = '1000000';
	    $config['overwrite'] = TRUE;
	    $config['remove_spaces'] = TRUE;
	    $this->load->library('upload', $config);
	    $this->upload->initialize($config);
        echo PropertyBrochureURL; 
		if($this->upload->do_upload('PropertyBrochureURL')){
		$upload_data2 = $this->upload->data();
		}else{
		echo $this->upload->display_errors();
		}
	}




 public function file_upload(){


		$config['upload_path'] = './assests/uploads/';
	    $config['allowed_types'] = 'gif|jpg|png|pdf';
	    $config['max_size'] = '3000000';
	    $config['max_width']  = '1000000';
	    $config['max_height']  = '1000000';
	    $config['overwrite'] = TRUE;
	    $config['remove_spaces'] = TRUE;
	    $this->load->library('upload', $config);

    $files = $_FILES;
    $cpt = count($_FILES['files']['name']);
    for($i=0; $i<$cpt; $i++)
    {           
        $_FILES['files']['name']= $files['files']['name'][$i];
        $_FILES['files']['type']= $files['files']['type'][$i];
        $_FILES['files']['tmp_name']= $files['files']['tmp_name'][$i];
        $_FILES['files']['error']= $files['files']['error'][$i];
        $_FILES['files']['size']= $files['files']['size'][$i];    

	    $this->upload->initialize($config);
         // $this->upload->do_upload('files[]');
        if (!$this->upload->do_upload('files'))
        {  
            $error =['error' => $this->upload->display_errors()];

        }
         else{
         	$upload_data = $this->upload->data();
         	
    $date = date('Y-m-d H:i:s');
  $file_data = array(
  	'PropertyCampaignId'=>'123',
  'ImageUrl' => $upload_data['full_path'],
			'CreateUserId'=>'srinathprabhu95@gmail.com',
			'CreateDate'=>$date
  );
  $this->db->insert('`imagepropertyassociation`', $file_data);
  }

                
            
}
}


public function set_upload_options()
{
    $config['upload_path'] = './assests/upload/';
    $config['allowed_types'] = 'gif|jpg|jpeg|png';
    $config['remove_spaces'] = true;
    return $config;
}

public function upload_image($fileName)
{
if($filename!='' ){
	$date = date('Y-m-d H:i:s');
      $filename1 = explode(",",$filename);
  foreach($filename1 as $file){
  $file_data = array(
  	'PropertyCampaignId'=>'123',
  'ImageUrl' => $file,
			'CreateUserId'=>'srinathprabhu95@gmail.com',
			'CreateDate'=>$date
  );
  $this->db->insert('`imagepropertyassociation`', $file_data);
  }
  }
}
}
?>